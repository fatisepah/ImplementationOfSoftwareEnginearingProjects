﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class UserControl1 : WindowsFormsApplication1.main_UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }
    }
}
